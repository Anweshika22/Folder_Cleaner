# 🧹 Folder Cleaner & Organizer (Python)

This is a simple and powerful Python script that organizes files in a directory based on file types. It's designed to automatically move files into subfolders (like PDFs/, Images/, Videos/) and optionally clean up duplicate names and empty folders.

## ✅ Features

- 📁 **Auto-categorizes files** by extension (e.g., `.pdf` → PDFs/, `.jpg` → Images/)
- 🔁 **Renames duplicate files** automatically (`file (1).pdf`)
- 🧼 **Deletes empty folders** (optional)
- 🧠 Uses **only standard Python libraries** (`os`, `shutil`, `sys`)

## 🚀 How to Use

```bash
python folder_cleaner.py <path_to_folder> [--delete-empty]
```

Example:
```bash
python folder_cleaner.py C:\Users\YourName\Downloads --delete-empty
```

## 🛠️ Customize

To add more categories or extensions, simply modify the `EXTENSION_MAP` dictionary at the top of the script.

## 💼 Real-Life Use Case

- Clean messy **Downloads** folders.
- Organize project folders for **designers**, **developers**, and **students**.
- Helps boost productivity and reduce manual work.

## 📌 Tech Stack

- Python 3.x
- `os`, `shutil`, `sys` — no external libraries

## 👩‍💻 Author

Anweshika Shrivastava  
*CS Student | Aspiring Data Engineer | Python Enthusiast*

## 📜 License

MIT License – free to use and modify.
