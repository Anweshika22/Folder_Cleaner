import os
import shutil

# Define the folder-to-extension mapping
EXTENSION_MAP = {
    'Images': ['.jpg', '.jpeg', '.png', '.gif', '.bmp'],
    'Documents': ['.pdf', '.docx', '.txt', '.doc'],
    'Videos': ['.mp4', '.mov', '.avi', '.mkv'],
    'Music': ['.mp3', '.wav', '.aac'],
    'Archives': ['.zip', '.rar', '.tar', '.gz'],
    'Spreadsheets': ['.xls', '.xlsx', '.csv'],
    'Scripts': ['.py', '.js', '.sh'],
    'Executables': ['.exe', '.msi']
}

def get_category(extension):
    for category, extensions in EXTENSION_MAP.items():
        if extension.lower() in extensions:
            return category
    return 'Others'

def ensure_unique_filename(dest_folder, filename):
    base, ext = os.path.splitext(filename)
    counter = 1
    while os.path.exists(os.path.join(dest_folder, filename)):
        filename = f"{base} ({counter}){ext}"
        counter += 1
    return filename

def organize_folder(folder_path, delete_empty=False):
    if not os.path.isdir(folder_path):
        print("Invalid directory path.")
        return

    for item in os.listdir(folder_path):
        item_path = os.path.join(folder_path, item)

        if os.path.isfile(item_path):
            _, ext = os.path.splitext(item)
            category = get_category(ext)
            dest_folder = os.path.join(folder_path, category)

            if not os.path.exists(dest_folder):
                os.makedirs(dest_folder)

            new_name = ensure_unique_filename(dest_folder, item)
            shutil.move(item_path, os.path.join(dest_folder, new_name))

    if delete_empty:
        for root, dirs, _ in os.walk(folder_path, topdown=False):
            for d in dirs:
                dir_path = os.path.join(root, d)
                if not os.listdir(dir_path):
                    os.rmdir(dir_path)

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python folder_cleaner.py <folder_path> [--delete-empty]")
    else:
        path = sys.argv[1]
        delete_flag = '--delete-empty' in sys.argv
        organize_folder(path, delete_empty=delete_flag)
